﻿namespace WindowsFormsApp3
{
    partial class Form1
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Button sinButton;
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.gradientPanel1 = new WindowsFormsApp3.GradientPanel();
            this.history = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.esittir = new WindowsFormsApp3.CircularButton();
            this.button4 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.mod = new System.Windows.Forms.Button();
            this.cot = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.Sayi1 = new WindowsFormsApp3.CircularButton();
            this.sayi6 = new WindowsFormsApp3.CircularButton();
            this.circularButton1 = new WindowsFormsApp3.CircularButton();
            this.sayi7 = new WindowsFormsApp3.CircularButton();
            this.sayi8 = new WindowsFormsApp3.CircularButton();
            this.button13 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.sayi2 = new WindowsFormsApp3.CircularButton();
            this.circularButton7 = new WindowsFormsApp3.CircularButton();
            this.sayi5 = new WindowsFormsApp3.CircularButton();
            this.sayi4 = new WindowsFormsApp3.CircularButton();
            this.clearbutton = new WindowsFormsApp3.CircularButton();
            this.morebutton = new System.Windows.Forms.Button();
            this.logbutton = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.sayi9 = new WindowsFormsApp3.CircularButton();
            this.sayi3 = new WindowsFormsApp3.CircularButton();
            this.cosbutton = new System.Windows.Forms.Button();
            sinButton = new System.Windows.Forms.Button();
            this.gradientPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // gradientPanel1
            // 
            this.gradientPanel1.Angle = 60F;
            this.gradientPanel1.BackColor = System.Drawing.Color.Transparent;
            this.gradientPanel1.BottomColor = System.Drawing.Color.DarkGray;
            this.gradientPanel1.Controls.Add(this.history);
            this.gradientPanel1.Controls.Add(this.label2);
            this.gradientPanel1.Controls.Add(this.label1);
            this.gradientPanel1.Controls.Add(this.esittir);
            this.gradientPanel1.Controls.Add(this.button4);
            this.gradientPanel1.Controls.Add(this.button20);
            this.gradientPanel1.Controls.Add(this.button19);
            this.gradientPanel1.Controls.Add(this.button18);
            this.gradientPanel1.Controls.Add(this.button17);
            this.gradientPanel1.Controls.Add(this.button16);
            this.gradientPanel1.Controls.Add(this.button15);
            this.gradientPanel1.Controls.Add(this.mod);
            this.gradientPanel1.Controls.Add(this.cot);
            this.gradientPanel1.Controls.Add(this.button3);
            this.gradientPanel1.Controls.Add(this.button2);
            this.gradientPanel1.Controls.Add(this.button1);
            this.gradientPanel1.Controls.Add(this.panel3);
            this.gradientPanel1.Controls.Add(this.panel2);
            this.gradientPanel1.Controls.Add(this.panel1);
            this.gradientPanel1.Controls.Add(this.Sayi1);
            this.gradientPanel1.Controls.Add(this.sayi6);
            this.gradientPanel1.Controls.Add(this.circularButton1);
            this.gradientPanel1.Controls.Add(this.sayi7);
            this.gradientPanel1.Controls.Add(this.sayi8);
            this.gradientPanel1.Controls.Add(this.button13);
            this.gradientPanel1.Controls.Add(this.button12);
            this.gradientPanel1.Controls.Add(this.button11);
            this.gradientPanel1.Controls.Add(this.button10);
            this.gradientPanel1.Controls.Add(this.button9);
            this.gradientPanel1.Controls.Add(this.button8);
            this.gradientPanel1.Controls.Add(this.sayi2);
            this.gradientPanel1.Controls.Add(this.circularButton7);
            this.gradientPanel1.Controls.Add(this.sayi5);
            this.gradientPanel1.Controls.Add(this.sayi4);
            this.gradientPanel1.Controls.Add(this.clearbutton);
            this.gradientPanel1.Controls.Add(sinButton);
            this.gradientPanel1.Controls.Add(this.morebutton);
            this.gradientPanel1.Controls.Add(this.logbutton);
            this.gradientPanel1.Controls.Add(this.button5);
            this.gradientPanel1.Controls.Add(this.button7);
            this.gradientPanel1.Controls.Add(this.sayi9);
            this.gradientPanel1.Controls.Add(this.sayi3);
            this.gradientPanel1.Controls.Add(this.cosbutton);
            this.gradientPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gradientPanel1.Location = new System.Drawing.Point(0, 0);
            this.gradientPanel1.Margin = new System.Windows.Forms.Padding(2);
            this.gradientPanel1.MaximumSize = new System.Drawing.Size(736, 736);
            this.gradientPanel1.MinimumSize = new System.Drawing.Size(420, 420);
            this.gradientPanel1.Name = "gradientPanel1";
            this.gradientPanel1.Size = new System.Drawing.Size(735, 660);
            this.gradientPanel1.TabIndex = 40;
            this.gradientPanel1.TopColor = System.Drawing.Color.Moccasin;
            // 
            // history
            // 
            this.history.Font = new System.Drawing.Font("Lucida Sans", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.history.ForeColor = System.Drawing.Color.LightGray;
            this.history.Location = new System.Drawing.Point(503, 127);
            this.history.Name = "history";
            this.history.Size = new System.Drawing.Size(229, 526);
            this.history.TabIndex = 61;
            this.history.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label2
            // 
            this.label2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label2.Font = new System.Drawing.Font("Lucida Sans", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Silver;
            this.label2.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label2.Location = new System.Drawing.Point(1, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(734, 34);
            this.label2.TabIndex = 60;
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label1
            // 
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label1.Font = new System.Drawing.Font("Lucida Sans", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label1.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label1.Location = new System.Drawing.Point(1, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(734, 34);
            this.label1.TabIndex = 59;
            this.label1.Text = "0";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // esittir
            // 
            this.esittir.Angle = 0F;
            this.esittir.AutoSize = true;
            this.esittir.BottomColor = System.Drawing.Color.Empty;
            this.esittir.FlatAppearance.BorderSize = 0;
            this.esittir.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.esittir.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.esittir.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.esittir.Font = new System.Drawing.Font("Lucida Sans", 87.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.esittir.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.esittir.Location = new System.Drawing.Point(101, 255);
            this.esittir.Name = "esittir";
            this.esittir.Size = new System.Drawing.Size(209, 211);
            this.esittir.TabIndex = 58;
            this.esittir.Text = "=";
            this.esittir.TopColor = System.Drawing.Color.Empty;
            this.esittir.UseVisualStyleBackColor = true;
            this.esittir.Click += new System.EventHandler(this.Esittir_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Transparent;
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Lucida Sans", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.Gray;
            this.button4.Location = new System.Drawing.Point(412, 73);
            this.button4.Margin = new System.Windows.Forms.Padding(2);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(58, 53);
            this.button4.TabIndex = 57;
            this.button4.Text = "   x";
            this.button4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.Nomore_Click);
            // 
            // button20
            // 
            this.button20.BackColor = System.Drawing.Color.Transparent;
            this.button20.FlatAppearance.BorderSize = 0;
            this.button20.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button20.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button20.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button20.Font = new System.Drawing.Font("Lucida Sans", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button20.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.button20.Location = new System.Drawing.Point(498, 72);
            this.button20.Margin = new System.Windows.Forms.Padding(2);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(236, 53);
            this.button20.TabIndex = 56;
            this.button20.Text = "History";
            this.button20.UseVisualStyleBackColor = false;
            // 
            // button19
            // 
            this.button19.BackColor = System.Drawing.Color.Transparent;
            this.button19.FlatAppearance.BorderSize = 0;
            this.button19.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.button19.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button19.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button19.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button19.Font = new System.Drawing.Font("Lucida Sans", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button19.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.button19.Location = new System.Drawing.Point(411, 602);
            this.button19.Margin = new System.Windows.Forms.Padding(2);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(87, 54);
            this.button19.TabIndex = 55;
            this.button19.Text = "cosh";
            this.button19.UseVisualStyleBackColor = false;
            this.button19.Click += new System.EventHandler(this.Cosh_Click);
            // 
            // button18
            // 
            this.button18.BackColor = System.Drawing.Color.Transparent;
            this.button18.FlatAppearance.BorderSize = 0;
            this.button18.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.button18.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button18.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button18.Font = new System.Drawing.Font("Lucida Sans", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button18.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.button18.Location = new System.Drawing.Point(411, 549);
            this.button18.Margin = new System.Windows.Forms.Padding(2);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(87, 55);
            this.button18.TabIndex = 54;
            this.button18.Text = "sinh";
            this.button18.UseVisualStyleBackColor = false;
            this.button18.Click += new System.EventHandler(this.Sinh_Click);
            // 
            // button17
            // 
            this.button17.BackColor = System.Drawing.Color.Transparent;
            this.button17.FlatAppearance.BorderSize = 0;
            this.button17.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.button17.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button17.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button17.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button17.Font = new System.Drawing.Font("Lucida Sans", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button17.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.button17.Location = new System.Drawing.Point(411, 495);
            this.button17.Margin = new System.Windows.Forms.Padding(2);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(87, 57);
            this.button17.TabIndex = 53;
            this.button17.Text = "π";
            this.button17.UseVisualStyleBackColor = false;
            this.button17.Click += new System.EventHandler(this.Pi_Click);
            // 
            // button16
            // 
            this.button16.BackColor = System.Drawing.Color.Transparent;
            this.button16.FlatAppearance.BorderSize = 0;
            this.button16.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.button16.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button16.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button16.Font = new System.Drawing.Font("Lucida Sans", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button16.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.button16.Location = new System.Drawing.Point(411, 441);
            this.button16.Margin = new System.Windows.Forms.Padding(2);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(87, 57);
            this.button16.TabIndex = 52;
            this.button16.Text = "ln x";
            this.button16.UseVisualStyleBackColor = false;
            this.button16.Click += new System.EventHandler(this.Ln_Click);
            // 
            // button15
            // 
            this.button15.BackColor = System.Drawing.Color.Transparent;
            this.button15.FlatAppearance.BorderSize = 0;
            this.button15.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.button15.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button15.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button15.Font = new System.Drawing.Font("Lucida Sans", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button15.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.button15.Location = new System.Drawing.Point(411, 387);
            this.button15.Margin = new System.Windows.Forms.Padding(2);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(87, 57);
            this.button15.TabIndex = 51;
            this.button15.Text = "e";
            this.button15.UseVisualStyleBackColor = false;
            this.button15.Click += new System.EventHandler(this.E_Click);
            // 
            // mod
            // 
            this.mod.BackColor = System.Drawing.Color.Transparent;
            this.mod.FlatAppearance.BorderSize = 0;
            this.mod.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.mod.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.mod.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.mod.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.mod.Font = new System.Drawing.Font("Lucida Sans", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mod.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.mod.Location = new System.Drawing.Point(411, 334);
            this.mod.Margin = new System.Windows.Forms.Padding(2);
            this.mod.Name = "mod";
            this.mod.Size = new System.Drawing.Size(87, 57);
            this.mod.TabIndex = 50;
            this.mod.Text = "mod";
            this.mod.UseVisualStyleBackColor = false;
            this.mod.Click += new System.EventHandler(this.Aritmetik_Islemler_Click);
            // 
            // cot
            // 
            this.cot.BackColor = System.Drawing.Color.Transparent;
            this.cot.FlatAppearance.BorderSize = 0;
            this.cot.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.cot.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.cot.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.cot.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cot.Font = new System.Drawing.Font("Lucida Sans", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cot.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.cot.Location = new System.Drawing.Point(411, 280);
            this.cot.Margin = new System.Windows.Forms.Padding(2);
            this.cot.Name = "cot";
            this.cot.Size = new System.Drawing.Size(87, 57);
            this.cot.TabIndex = 49;
            this.cot.Text = "cot";
            this.cot.UseVisualStyleBackColor = false;
            this.cot.Click += new System.EventHandler(this.Cot_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Transparent;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.button3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Lucida Sans", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.button3.Location = new System.Drawing.Point(411, 227);
            this.button3.Margin = new System.Windows.Forms.Padding(2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(87, 57);
            this.button3.TabIndex = 48;
            this.button3.Text = "tan";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.Tan_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Transparent;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.button2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Lucida Sans", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.button2.Location = new System.Drawing.Point(411, 173);
            this.button2.Margin = new System.Windows.Forms.Padding(2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(87, 57);
            this.button2.TabIndex = 47;
            this.button2.Text = "cos";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.Cos_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Transparent;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Lucida Sans", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.button1.Location = new System.Drawing.Point(411, 130);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(87, 46);
            this.button1.TabIndex = 46;
            this.button1.Text = "sin";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.Sin_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.SeaShell;
            this.panel3.Location = new System.Drawing.Point(0, 656);
            this.panel3.Margin = new System.Windows.Forms.Padding(2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(734, 4);
            this.panel3.TabIndex = 45;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.SeaShell;
            this.panel2.Location = new System.Drawing.Point(406, 72);
            this.panel2.Margin = new System.Windows.Forms.Padding(2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(4, 587);
            this.panel2.TabIndex = 41;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.SeaShell;
            this.panel1.Location = new System.Drawing.Point(1, 68);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(734, 4);
            this.panel1.TabIndex = 42;
            // 
            // Sayi1
            // 
            this.Sayi1.Angle = 0F;
            this.Sayi1.BackColor = System.Drawing.Color.BurlyWood;
            this.Sayi1.BottomColor = System.Drawing.Color.Empty;
            this.Sayi1.FlatAppearance.BorderSize = 0;
            this.Sayi1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.BurlyWood;
            this.Sayi1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.BurlyWood;
            this.Sayi1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Sayi1.Font = new System.Drawing.Font("Lucida Sans", 24F, System.Drawing.FontStyle.Bold);
            this.Sayi1.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.Sayi1.Location = new System.Drawing.Point(164, 155);
            this.Sayi1.Margin = new System.Windows.Forms.Padding(2);
            this.Sayi1.Name = "Sayi1";
            this.Sayi1.Size = new System.Drawing.Size(74, 74);
            this.Sayi1.TabIndex = 10;
            this.Sayi1.Text = "1";
            this.Sayi1.TopColor = System.Drawing.Color.Empty;
            this.Sayi1.UseVisualStyleBackColor = false;
            this.Sayi1.Click += new System.EventHandler(this.Numara_Click);
            // 
            // sayi6
            // 
            this.sayi6.Angle = 0F;
            this.sayi6.BackColor = System.Drawing.Color.LightSlateGray;
            this.sayi6.BottomColor = System.Drawing.Color.Empty;
            this.sayi6.FlatAppearance.BorderSize = 0;
            this.sayi6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sayi6.Font = new System.Drawing.Font("Lucida Sans", 24F, System.Drawing.FontStyle.Bold);
            this.sayi6.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.sayi6.Location = new System.Drawing.Point(257, 488);
            this.sayi6.Margin = new System.Windows.Forms.Padding(2);
            this.sayi6.Name = "sayi6";
            this.sayi6.Size = new System.Drawing.Size(74, 74);
            this.sayi6.TabIndex = 15;
            this.sayi6.Text = "6";
            this.sayi6.TopColor = System.Drawing.Color.Empty;
            this.sayi6.UseVisualStyleBackColor = false;
            this.sayi6.Click += new System.EventHandler(this.Numara_Click);
            // 
            // circularButton1
            // 
            this.circularButton1.Angle = 0F;
            this.circularButton1.BackColor = System.Drawing.Color.LightSteelBlue;
            this.circularButton1.BottomColor = System.Drawing.Color.Empty;
            this.circularButton1.FlatAppearance.BorderSize = 0;
            this.circularButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.circularButton1.Font = new System.Drawing.Font("Lucida Sans", 24F, System.Drawing.FontStyle.Bold);
            this.circularButton1.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.circularButton1.Location = new System.Drawing.Point(81, 176);
            this.circularButton1.Margin = new System.Windows.Forms.Padding(2);
            this.circularButton1.Name = "circularButton1";
            this.circularButton1.Size = new System.Drawing.Size(74, 74);
            this.circularButton1.TabIndex = 28;
            this.circularButton1.Text = "0";
            this.circularButton1.TopColor = System.Drawing.Color.IndianRed;
            this.circularButton1.UseVisualStyleBackColor = false;
            this.circularButton1.Click += new System.EventHandler(this.Numara_Click);
            // 
            // sayi7
            // 
            this.sayi7.Angle = 0F;
            this.sayi7.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.sayi7.BottomColor = System.Drawing.Color.Empty;
            this.sayi7.FlatAppearance.BorderSize = 0;
            this.sayi7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sayi7.Font = new System.Drawing.Font("Lucida Sans", 24F, System.Drawing.FontStyle.Bold);
            this.sayi7.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.sayi7.Location = new System.Drawing.Point(169, 510);
            this.sayi7.Margin = new System.Windows.Forms.Padding(2);
            this.sayi7.Name = "sayi7";
            this.sayi7.Size = new System.Drawing.Size(74, 74);
            this.sayi7.TabIndex = 14;
            this.sayi7.Text = "7";
            this.sayi7.TopColor = System.Drawing.Color.Empty;
            this.sayi7.UseVisualStyleBackColor = false;
            this.sayi7.Click += new System.EventHandler(this.Numara_Click);
            // 
            // sayi8
            // 
            this.sayi8.Angle = 0F;
            this.sayi8.BackColor = System.Drawing.Color.Thistle;
            this.sayi8.BottomColor = System.Drawing.Color.Empty;
            this.sayi8.FlatAppearance.BorderSize = 0;
            this.sayi8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sayi8.Font = new System.Drawing.Font("Lucida Sans", 24F, System.Drawing.FontStyle.Bold);
            this.sayi8.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.sayi8.Location = new System.Drawing.Point(78, 488);
            this.sayi8.Margin = new System.Windows.Forms.Padding(2);
            this.sayi8.Name = "sayi8";
            this.sayi8.Size = new System.Drawing.Size(74, 74);
            this.sayi8.TabIndex = 18;
            this.sayi8.Text = "8";
            this.sayi8.TopColor = System.Drawing.Color.Empty;
            this.sayi8.UseVisualStyleBackColor = false;
            this.sayi8.Click += new System.EventHandler(this.Numara_Click);
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.Transparent;
            this.button13.FlatAppearance.BorderSize = 0;
            this.button13.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button13.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button13.Font = new System.Drawing.Font("Lucida Sans", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button13.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.button13.Location = new System.Drawing.Point(1, 73);
            this.button13.Margin = new System.Windows.Forms.Padding(2);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(66, 57);
            this.button13.TabIndex = 34;
            this.button13.Text = "+";
            this.button13.UseVisualStyleBackColor = false;
            this.button13.Click += new System.EventHandler(this.Aritmetik_Islemler_Click);
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.Color.Transparent;
            this.button12.FlatAppearance.BorderSize = 0;
            this.button12.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button12.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button12.Font = new System.Drawing.Font("Lucida Sans", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button12.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.button12.Location = new System.Drawing.Point(68, 74);
            this.button12.Margin = new System.Windows.Forms.Padding(2);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(66, 54);
            this.button12.TabIndex = 35;
            this.button12.Text = "-";
            this.button12.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button12.UseVisualStyleBackColor = false;
            this.button12.Click += new System.EventHandler(this.Aritmetik_Islemler_Click);
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.Color.Transparent;
            this.button11.FlatAppearance.BorderSize = 0;
            this.button11.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button11.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button11.Font = new System.Drawing.Font("Lucida Sans", 24F, System.Drawing.FontStyle.Bold);
            this.button11.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.button11.Location = new System.Drawing.Point(135, 73);
            this.button11.Margin = new System.Windows.Forms.Padding(2);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(66, 54);
            this.button11.TabIndex = 36;
            this.button11.Text = "x";
            this.button11.UseVisualStyleBackColor = false;
            this.button11.Click += new System.EventHandler(this.Aritmetik_Islemler_Click);
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.Transparent;
            this.button10.FlatAppearance.BorderSize = 0;
            this.button10.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button10.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button10.Font = new System.Drawing.Font("Lucida Sans", 24F, System.Drawing.FontStyle.Bold);
            this.button10.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.button10.Location = new System.Drawing.Point(201, 73);
            this.button10.Margin = new System.Windows.Forms.Padding(2);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(66, 54);
            this.button10.TabIndex = 37;
            this.button10.Text = "÷";
            this.button10.UseVisualStyleBackColor = false;
            this.button10.Click += new System.EventHandler(this.Aritmetik_Islemler_Click);
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.Transparent;
            this.button9.FlatAppearance.BorderSize = 0;
            this.button9.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button9.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.Font = new System.Drawing.Font("Lucida Sans", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.button9.Location = new System.Drawing.Point(257, 73);
            this.button9.Margin = new System.Windows.Forms.Padding(2);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(71, 54);
            this.button9.TabIndex = 38;
            this.button9.Text = "%";
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.Aritmetik_Islemler_Click);
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.Transparent;
            this.button8.FlatAppearance.BorderSize = 0;
            this.button8.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button8.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Font = new System.Drawing.Font("Lucida Sans", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.button8.Location = new System.Drawing.Point(322, 73);
            this.button8.Margin = new System.Windows.Forms.Padding(2);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(83, 54);
            this.button8.TabIndex = 39;
            this.button8.Text = "DEL";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.Sil_Click);
            // 
            // sayi2
            // 
            this.sayi2.Angle = 0F;
            this.sayi2.BackColor = System.Drawing.Color.MediumAquamarine;
            this.sayi2.BottomColor = System.Drawing.Color.Empty;
            this.sayi2.FlatAppearance.BorderSize = 0;
            this.sayi2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sayi2.Font = new System.Drawing.Font("Lucida Sans", 24F, System.Drawing.FontStyle.Bold);
            this.sayi2.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.sayi2.Location = new System.Drawing.Point(246, 172);
            this.sayi2.Margin = new System.Windows.Forms.Padding(2);
            this.sayi2.Name = "sayi2";
            this.sayi2.Size = new System.Drawing.Size(74, 74);
            this.sayi2.TabIndex = 13;
            this.sayi2.Text = "2";
            this.sayi2.TopColor = System.Drawing.Color.Empty;
            this.sayi2.UseVisualStyleBackColor = false;
            this.sayi2.Click += new System.EventHandler(this.Numara_Click);
            // 
            // circularButton7
            // 
            this.circularButton7.Angle = 0F;
            this.circularButton7.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.circularButton7.BottomColor = System.Drawing.Color.Empty;
            this.circularButton7.FlatAppearance.BorderSize = 0;
            this.circularButton7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.circularButton7.Font = new System.Drawing.Font("Lucida Sans", 24F, System.Drawing.FontStyle.Bold);
            this.circularButton7.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.circularButton7.Location = new System.Drawing.Point(3, 324);
            this.circularButton7.Margin = new System.Windows.Forms.Padding(2);
            this.circularButton7.Name = "circularButton7";
            this.circularButton7.Size = new System.Drawing.Size(74, 74);
            this.circularButton7.TabIndex = 16;
            this.circularButton7.Text = ".";
            this.circularButton7.TopColor = System.Drawing.Color.Empty;
            this.circularButton7.UseVisualStyleBackColor = false;
            this.circularButton7.Click += new System.EventHandler(this.Numara_Click);
            // 
            // sayi5
            // 
            this.sayi5.Angle = 0F;
            this.sayi5.BackColor = System.Drawing.Color.LightSteelBlue;
            this.sayi5.BottomColor = System.Drawing.Color.Empty;
            this.sayi5.FlatAppearance.BorderSize = 0;
            this.sayi5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sayi5.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold);
            this.sayi5.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.sayi5.Location = new System.Drawing.Point(312, 415);
            this.sayi5.Margin = new System.Windows.Forms.Padding(2);
            this.sayi5.Name = "sayi5";
            this.sayi5.Size = new System.Drawing.Size(74, 74);
            this.sayi5.TabIndex = 19;
            this.sayi5.Text = "5";
            this.sayi5.TopColor = System.Drawing.Color.Empty;
            this.sayi5.UseVisualStyleBackColor = false;
            this.sayi5.Click += new System.EventHandler(this.Numara_Click);
            // 
            // sayi4
            // 
            this.sayi4.Angle = 0F;
            this.sayi4.BackColor = System.Drawing.Color.LightGray;
            this.sayi4.BottomColor = System.Drawing.Color.Empty;
            this.sayi4.FlatAppearance.BorderSize = 0;
            this.sayi4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sayi4.Font = new System.Drawing.Font("Lucida Sans", 24F, System.Drawing.FontStyle.Bold);
            this.sayi4.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.sayi4.Location = new System.Drawing.Point(328, 325);
            this.sayi4.Margin = new System.Windows.Forms.Padding(2);
            this.sayi4.Name = "sayi4";
            this.sayi4.Size = new System.Drawing.Size(74, 74);
            this.sayi4.TabIndex = 21;
            this.sayi4.Text = "4";
            this.sayi4.TopColor = System.Drawing.Color.Empty;
            this.sayi4.UseVisualStyleBackColor = false;
            this.sayi4.Click += new System.EventHandler(this.Numara_Click);
            // 
            // clearbutton
            // 
            this.clearbutton.Angle = 0F;
            this.clearbutton.BackColor = System.Drawing.Color.LightSalmon;
            this.clearbutton.BottomColor = System.Drawing.Color.Empty;
            this.clearbutton.FlatAppearance.BorderSize = 0;
            this.clearbutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.clearbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold);
            this.clearbutton.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.clearbutton.Location = new System.Drawing.Point(22, 238);
            this.clearbutton.Margin = new System.Windows.Forms.Padding(2);
            this.clearbutton.Name = "clearbutton";
            this.clearbutton.Size = new System.Drawing.Size(74, 74);
            this.clearbutton.TabIndex = 4;
            this.clearbutton.Text = "C";
            this.clearbutton.TopColor = System.Drawing.Color.Empty;
            this.clearbutton.UseVisualStyleBackColor = false;
            this.clearbutton.Click += new System.EventHandler(this.Temizle_Click);
            // 
            // sinButton
            // 
            sinButton.BackColor = System.Drawing.Color.Transparent;
            sinButton.FlatAppearance.BorderSize = 0;
            sinButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            sinButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            sinButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            sinButton.Font = new System.Drawing.Font("Lucida Sans", 16.2F, System.Drawing.FontStyle.Bold);
            sinButton.ForeColor = System.Drawing.Color.WhiteSmoke;
            sinButton.Location = new System.Drawing.Point(2, 599);
            sinButton.Margin = new System.Windows.Forms.Padding(2);
            sinButton.Name = "sinButton";
            sinButton.Size = new System.Drawing.Size(66, 57);
            sinButton.TabIndex = 22;
            sinButton.Text = "+/-";
            sinButton.UseVisualStyleBackColor = false;
            sinButton.Click += new System.EventHandler(this.artieksi_Click);
            // 
            // morebutton
            // 
            this.morebutton.BackColor = System.Drawing.Color.Transparent;
            this.morebutton.FlatAppearance.BorderSize = 0;
            this.morebutton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.morebutton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.morebutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.morebutton.Font = new System.Drawing.Font("Lucida Sans", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.morebutton.ForeColor = System.Drawing.Color.Gray;
            this.morebutton.Location = new System.Drawing.Point(322, 599);
            this.morebutton.Margin = new System.Windows.Forms.Padding(2);
            this.morebutton.Name = "morebutton";
            this.morebutton.Size = new System.Drawing.Size(83, 57);
            this.morebutton.TabIndex = 30;
            this.morebutton.Text = "more";
            this.morebutton.UseVisualStyleBackColor = false;
            this.morebutton.Click += new System.EventHandler(this.More_Click);
            // 
            // logbutton
            // 
            this.logbutton.BackColor = System.Drawing.Color.Transparent;
            this.logbutton.FlatAppearance.BorderSize = 0;
            this.logbutton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.logbutton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.logbutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.logbutton.Font = new System.Drawing.Font("Lucida Sans", 16.2F, System.Drawing.FontStyle.Bold);
            this.logbutton.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.logbutton.Location = new System.Drawing.Point(199, 599);
            this.logbutton.Margin = new System.Windows.Forms.Padding(2);
            this.logbutton.Name = "logbutton";
            this.logbutton.Size = new System.Drawing.Size(66, 57);
            this.logbutton.TabIndex = 31;
            this.logbutton.Text = "log";
            this.logbutton.UseVisualStyleBackColor = false;
            this.logbutton.Click += new System.EventHandler(this.Log_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.Transparent;
            this.button5.FlatAppearance.BorderSize = 0;
            this.button5.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button5.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Lucida Sans", 16.2F, System.Drawing.FontStyle.Bold);
            this.button5.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.button5.Location = new System.Drawing.Point(260, 599);
            this.button5.Margin = new System.Windows.Forms.Padding(2);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(66, 57);
            this.button5.TabIndex = 32;
            this.button5.Text = "√";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.Karekok_Click);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.Transparent;
            this.button7.FlatAppearance.BorderSize = 0;
            this.button7.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button7.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Font = new System.Drawing.Font("Lucida Sans", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.button7.Location = new System.Drawing.Point(133, 599);
            this.button7.Margin = new System.Windows.Forms.Padding(2);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(66, 57);
            this.button7.TabIndex = 33;
            this.button7.Text = "xʸ";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.Aritmetik_Islemler_Click);
            // 
            // sayi9
            // 
            this.sayi9.Angle = 0F;
            this.sayi9.BackColor = System.Drawing.Color.Khaki;
            this.sayi9.BottomColor = System.Drawing.Color.Empty;
            this.sayi9.FlatAppearance.BorderSize = 0;
            this.sayi9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sayi9.Font = new System.Drawing.Font("Lucida Sans", 24F, System.Drawing.FontStyle.Bold);
            this.sayi9.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.sayi9.Location = new System.Drawing.Point(18, 416);
            this.sayi9.Margin = new System.Windows.Forms.Padding(2);
            this.sayi9.Name = "sayi9";
            this.sayi9.Size = new System.Drawing.Size(74, 74);
            this.sayi9.TabIndex = 20;
            this.sayi9.Text = "9";
            this.sayi9.TopColor = System.Drawing.Color.Empty;
            this.sayi9.UseVisualStyleBackColor = false;
            this.sayi9.Click += new System.EventHandler(this.Numara_Click);
            // 
            // sayi3
            // 
            this.sayi3.Angle = 0F;
            this.sayi3.BackColor = System.Drawing.Color.RosyBrown;
            this.sayi3.BottomColor = System.Drawing.Color.Empty;
            this.sayi3.FlatAppearance.BorderSize = 0;
            this.sayi3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sayi3.Font = new System.Drawing.Font("Lucida Sans", 24F, System.Drawing.FontStyle.Bold);
            this.sayi3.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.sayi3.Location = new System.Drawing.Point(309, 234);
            this.sayi3.Margin = new System.Windows.Forms.Padding(2);
            this.sayi3.Name = "sayi3";
            this.sayi3.Size = new System.Drawing.Size(74, 74);
            this.sayi3.TabIndex = 17;
            this.sayi3.Text = "3";
            this.sayi3.TopColor = System.Drawing.Color.Empty;
            this.sayi3.UseVisualStyleBackColor = false;
            this.sayi3.Click += new System.EventHandler(this.Numara_Click);
            // 
            // cosbutton
            // 
            this.cosbutton.BackColor = System.Drawing.Color.Transparent;
            this.cosbutton.FlatAppearance.BorderSize = 0;
            this.cosbutton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.cosbutton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.cosbutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cosbutton.Font = new System.Drawing.Font("Lucida Sans", 16.2F, System.Drawing.FontStyle.Bold);
            this.cosbutton.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.cosbutton.Location = new System.Drawing.Point(67, 599);
            this.cosbutton.Margin = new System.Windows.Forms.Padding(2);
            this.cosbutton.Name = "cosbutton";
            this.cosbutton.Size = new System.Drawing.Size(66, 57);
            this.cosbutton.TabIndex = 29;
            this.cosbutton.Text = "n!";
            this.cosbutton.UseVisualStyleBackColor = false;
            this.cosbutton.Click += new System.EventHandler(this.faktoryel_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DimGray;
            this.ClientSize = new System.Drawing.Size(735, 660);
            this.Controls.Add(this.gradientPanel1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.gradientPanel1.ResumeLayout(false);
            this.gradientPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private CircularButton clearbutton;
        private CircularButton Sayi1;
        private CircularButton sayi2;
        private CircularButton sayi7;
        private CircularButton sayi6;
        private CircularButton circularButton7;
        private CircularButton sayi3;
        private CircularButton sayi8;
        private CircularButton sayi5;
        private CircularButton sayi9;
        private CircularButton sayi4;
        private System.Windows.Forms.Button cosbutton;
        private System.Windows.Forms.Button morebutton;
        private System.Windows.Forms.Button logbutton;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button8;
        private GradientPanel gradientPanel1;
        private CircularButton circularButton1;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button mod;
        private System.Windows.Forms.Button cot;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button4;
        private CircularButton esittir;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label history;
    }
}

